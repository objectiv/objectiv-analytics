"""
Copyright 2021 Objectiv B.V.

All information is in setup.cfg. But it seems 'pip install -e' likes to have a setup.py, so we have this
file. We might need to look more in into the whole packaging thing in the future.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
